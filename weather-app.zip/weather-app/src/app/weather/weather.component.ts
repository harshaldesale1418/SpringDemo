// import { Component, inject, effect } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// import { rxResource } from '@angular/core/rxjs-interop';
// import { JsonPipe, NgIf } from '@angular/common';

// @Component({
//   selector: 'app-weather',
//   standalone: true,
//     imports: [JsonPipe, NgIf], 
//   template: `
//     <h2>🌤️ Weather in Pune</h2>

//     @if (weather.isLoading()) {
//       <p>Loading...</p>
//     } @else if (weather.error()) {
//       <p>Error: {{ weather.error() | json }}</p>
//     } @else if (weather.value()) {
//       <pre>{{ weather.value() | json }}</pre>
//     }
//   `
// })
// export class WeatherComponent {
//   private http = inject(HttpClient);

//   weather = rxResource({
//     loader: () =>
//       this.http.get<any>(
//         'https://api.open-meteo.com/v1/forecast?latitude=18.5204&longitude=73.8567&current_weather=true'
//       )
//   });

//   constructor() {
//     // Debug log every time the resource changes
//     effect(() => {
//       console.log('Weather Resource:', {
//         loading: this.weather.isLoading(),
//         error: this.weather.error(),
//         data: this.weather.value()
//       });
//     });
//   }
  
// }
import { Component, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { rxResource } from '@angular/core/rxjs-interop';
import { NgIf,NgFor } from '@angular/common';

type City = 'Pune' | 'Jalgaon' | 'Mumbai' | 'Delhi';

@Component({
  selector: 'app-weather',
  standalone: true,
  imports: [NgIf,NgFor],
  template: `
    <h2>🌤️ City Weather Info</h2>

    <label>
      Select City:
      <select [value]="selectedCity()" (change)="onCityChange($event)">
        <option *ngFor="let city of cityNames" [value]="city">{{ city }}</option>
      </select>
    </label>

    <!-- Primary @if with 'as' -->
    @if (weather.value(); as w) {
      <div class="weather-card">
        <h3>{{ selectedCity() }} Weather</h3>
        <p>🌡️ Temperature: {{ w.current_weather.temperature }} °C</p>
        <p>💨 Windspeed: {{ w.current_weather.windspeed }} km/h</p>
        <p>🧭 Wind Direction: {{ w.current_weather.winddirection }}°</p>
        <p>⏰ Time: {{ w.current_weather.time }}</p>
      </div>
    } 
    @else if (weather.isLoading()) {
      <p>Loading weather data...</p>
    } 
    @else if (weather.error()) {
      <p>❌ Error: {{ weather.error() }}</p>
    }
  `,
  styles: [`
    .weather-card {
      margin-top: 10px;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 8px;
      width: 250px;
    }
    select {
      margin-left: 8px;
      padding: 4px;
    }
  `]
})
export class WeatherComponent {
  private http = inject(HttpClient);

  cities: Record<City, { lat: number; lon: number }> = {
    Pune: { lat: 18.5204, lon: 73.8567 },
    Jalgaon: { lat: 21.0077, lon: 75.5626 },
    Mumbai: { lat: 19.0760, lon: 72.8777 },
    Delhi: { lat: 28.6139, lon: 77.2090 }
  };

  cityNames = Object.keys(this.cities) as City[];
  selectedCity = signal<City>('Pune');

  weather = rxResource({
    loader: () => {
      const c = this.cities[this.selectedCity()];
      return this.http.get<any>(
        `https://api.open-meteo.com/v1/forecast?latitude=${c.lat}&longitude=${c.lon}&current_weather=true`
      );
    }
  });

  onCityChange(event: Event) {
    const value = (event.target as HTMLSelectElement).value as City;
    this.selectedCity.set(value);
    this.weather.reload();
  }
}
